// Select the relevant elements
const input = document.getElementById('item');
const button = document.getElementById('add');
const list = document.getElementById('shopping-list');

// Function to add a new item to the list
function addItem() {
    // Get the value of the input
    const value = input.value.trim();
    
    // Check if the input is not empty
    if (value !== '') {
        // Create a new list item
        const li = document.createElement('li');
        li.textContent = value;
        
        // Create a delete button for the item
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', () => {
            li.remove();
        });
        
        // Append the delete button to the list item
        li.appendChild(deleteButton);
        
        // Add the list item to the shopping list
        list.appendChild(li);
        
        // Clear the input field
        input.value = '';
    }
}

// Add an event listener to the button
button.addEventListener('click', addItem);

// Allow pressing Enter to add the item
input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        addItem();
    }
});
